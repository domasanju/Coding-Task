<html>
<body>
<form name="main" action="dologin.php">
<center>
<h1>Login page</h1>
</center>
<center>
<table><tr><td><label>UserName:</label></td>
<td><input type="text" name="uname" id="uname" required ></td></tr>
<tr><td><label>Password:</label></td>
<td><input type="password" name="pass" id="pass" required></td></tr>
<tr><td></td>
<td><input type="submit" name="submit" value="Login"/>
<a href="registration.php">Sign Up</a></td></tr>
</table>
</center>
</form>
</body>
</html>