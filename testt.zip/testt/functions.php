<?php 
	  include('dbcon.php');
function delete_record($delete_id)
	{
		$query = mysql_query("delete from stud_registration where stud_id='$delete_id'");
		if($query)
			return true;
		else{ 
			return false;
		}
		
	} 
	function viewstudent($id) 
	{
echo "dfsdfasfsfhsfhkdfhsklfhkdsfhkasdfh";		
		$data=[];
		if (!empty($id)) 
		{
					
			
			$sql = "SELECT * FROM stud_registration WHERE Stud_id = '".$id."'";
	        $query = mysql_query($sql) or trigger_error("Query Failed: " . mysql_error());
			if($sql)
			{
			while($res=mysql_fetch_array($query))
			{				
				$data['Stud_id']=$res['Stud_id'];
				$data['stud_name']=$res['stud_name'];
				$data['email']=$res['email'];
				$data['class']=$res['class'];
				$data['enroll_year']=$res['enroll_year'];
				$data['city']=$res['city'];
				$data['country']=$res['country'];
			}
			
			}
			else
	echo "<script>'alert($data)'</script>";			
			
		}
	return json_encode($data);
	}

?>