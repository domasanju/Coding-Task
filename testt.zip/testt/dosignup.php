<?php 
	  include('dbcon.php');
		$fname = $_GET['fname'];
		$mname = $_GET['mname'];
		$lname = $_GET['lname'];
		$email = $_GET['email'];
		$mbno = $_GET['mbno'];
		$pass1 = $_GET['pass'];
//$pass2 = $_GET['cpass'];

		
		$sql=mysql_query("insert into registration(fname,mname,lname,email,Mobile_No,password)values('$fname','$mname','$lname','$email','$mbno','$pass1')");
			if($sql){
				echo "<script>window.location='index.php';alert('Registration Successfull');</script>";
			}else{
				echo "<script>window.location='registration.php';alert('Registration Not Successfull, please try again');</script>";
			}
			
?>
		