<?php 
	  include('dbcon.php');
		$username = $_GET['uname'];
		$password = $_GET['pass'];
		$query = "SELECT * FROM registration WHERE Email='$username' AND Password='$password'";
		$result = mysql_query($query)or die(mysql_error());
		$row = mysql_fetch_array($result);
		$num_row = mysql_num_rows($result);		
		if($num_row>0) 
		{ 			
		echo '<script>window.location="dashboard.php";</script>';	
		}		
		else
		{
		echo '<script>window.location="index.php";alert("Please Enter Correct USername And Password");</script>';
		}
			
?>
		