<?php
include('dbcon.php');
include_once('functions.php');

//include_once('functions.php');
if(isset($_REQUEST['action']))
{
	switch(strtolower($_REQUEST['action']))
	{
		case 'delete_record':
		 if(delete_record($_REQUEST['delete_id']))
				echo "<script>window.location='dashboard.php';alert('Record Deleted Successfully');</script>";
			else 
				echo "<script>window.location='dashboard.php';alert('Record Not Deleted, try again');</script>";
		break;
		
			case 'student_update':
						//echo "<script>'alert(called)'</script>";		
		    echo student_update($_REQUEST['id']);
		break;
		
		case 'viewstudent':
						//echo "<script>'alert(called)'</script>";		
		    echo viewstudent($_REQUEST['id']);
		break;
	}
}