<?php 
    include('dbcon.php');
	//include_once('functions.php');

	$sql=mysql_query("select * from stud_registration order by stud_id desc LIMIT 1");	
    	while($result=mysql_fetch_row($sql))
		{
			     $fetch=$result['0'];
				  $nextid=$fetch+1;
				  //echo $nextid;
		}
				   
?>


<html>
<head>
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
   <script type = "text/javascript" src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js">
      </script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
     <script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	  <script src="//ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular.min.js"></script>
</head>
<script>
function ValidateEmail(mail) 
{
 if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(main.email.value))
  {
    return (true)
  }
    alert("You have entered an invalid email address!")
    return (false)
}
</script>
<body>
<form name="main" action="dosave.php">
<center>
<h1>DashBoard</h1>
</center>
<table colspan="10" cellpadding="5" cellspacing="20" width="100" style="display: inline-block; float:left; margin-left:20px;">
<tr><td>
<label>Student ID:</label><input type="text" name="studid" value="<?php echo $nextid ?>" id="studid" required READONLY></td></tr>
<tr><td>
<label>Student Name:</label>:<input type="text" name="studname" id="studname" required></td></tr>
<tr><td>
<label>Class :</label>:<input type="text" name="class" id="class" required></td></tr>
<tr><td>
<label> Email:</label>:<input type="text" name="email" id="email" required></td></tr>
<tr><td>
<label>Enrollment Year:</label>:<input type="text" name="enroll_yr" id="enroll_yr" required></td></tr>
<tr><td>
<label>City:</label>:<input type="text" name="city" id="city" required></td></tr>
<tr><td>
<label>Country:</label>:<input type="text" name="country" id="country" required></td></tr>
<tr><td>
<input type="submit" name="submit" value="Save" onclick="return ValidateEmail()"/>
<input type="reset" name="Clear" value="Clear"/></td></tr>
</table>
</form>
 
              <table id="example1" border="2" style="float: right; margin-right:30px; margin-top:20px;">
                <thead>
                <tr>
                   <th>ID</th>
				   <th>Name</th>
				  <th>Email</th>
				  <th>class</th>
				  <th>Year</th>
				  <th>city</th>
				  <th>Country</th>
				  <th>Action</th>
                </tr>
                </thead>
                <tbody>
               <?php 
					$sql=mysql_query("select * from stud_registration");
				if($sql)
				{
				while($result=mysql_fetch_array($sql))
					{
						echo "<tr>";					
						echo "<td>".$result['Stud_id']."</td>";
						echo "<td>".$result['stud_name']."</td>";
						echo "<td>".$result['email']."</td>";
						echo "<td>".$result['class']."</td>";
						echo "<td>".$result['enroll_year']."</td>";
						echo "<td>".$result['city']."</td>";
						echo "<td>".$result['country']."</td>";
						echo "<td>
							<button type='button' value='".$result['Stud_id']."' data-target='#view' data-toggle='modal' class='viewbtn'>View</button>
                      <button value='".$result['Stud_id']."' data-toggle='modal' data-target='#update' class='updatebtn' >Update</button>
					   <button value='".$result['Stud_id']."' data-toggle='modal' data-target='#delete' class='deletebtn' >Delete</button>
						</td>";
						echo "</tr>";						
					}
				}
				?>
                </tbody>
                <tfoot>
               
                </tfoot>
              </table>

<!--      ---------------update modal satrtttttttttttttttttttttttt-->

 <div class="modal fade" style="width:100%;" id="update" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true">
    <div class="modal-dialog" style="width:80%; height:800px;">
      <div class="modal-content">
        <div class="modal-header">
          <button type="reset" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
          <h4 class="modal-title" id=""><strong>Update Student Record</strong></h4>
        </div>
       <div class="modal-body">
        <form class="form-horizontal" method="POST" action="process.php?action=update_postschedule">
             <div class="modal-body">
				<div class="row">
				   <div class="col-md-6 col-sm-12 col-xs-12" id="">
						<div class="form-group">
						<label class="control-label col-md-4 col-sm-3 col-xs-12 lbl_reg">Student ID</label>						
						  <div class="col-md-8 col-sm-8 col-xs-12" >
							<input type="text" class="form-control"  id="studid" name="studid" readonly />
						  </div>
						</div>
					</div>
					<div class="col-md-6 col-sm-12 col-xs-12" id="">
						<div class="form-group">
						<label class="control-label col-md-4 col-sm-3 col-xs-12 lbl_reg">Student Name</label>						
						  <div class="col-md-8 col-sm-8 col-xs-12" >
							<input type="text" class="form-control"  id="studname" name="studname" />
						  </div>
						</div>
					</div>
				</div>
				<br>
				<div class="row">
				<div class="col-md-6 col-sm-12 col-xs-12" id="">
				<div class="form-group">
						<label class="control-label col-md-4 col-sm-3 col-xs-12" >Class</label>
							<div class="col-md-8 col-sm-8 col-xs-12" id="">
							<input type="text" class="form-control"  id="class" name="class"/>
							</div>
							</div>
				</div>
					<div class="col-md-6 col-sm-12 col-xs-12">
						<div class="form-group">
						<label class="control-label col-md-4 col-sm-3 col-xs-12 lbl_reg">Email</label>						
						  <div class="col-md-8 col-sm-8 col-xs-12" >
						   <input type="text" class="form-control"  id="email" name="email" />

						  </div>
						</div>
					
					</div>
			
				</div>
				<br>
				<div class="row">
				<div class="col-md-6 col-sm-12 col-xs-12">
						<div class="form-group">
						<label class="control-label col-md-4 col-sm-3 col-xs-12" >Enrollment Year</label>
							<div class="col-md-8 col-sm-8 col-xs-12">
									<input type="text" class="form-control" id="enrollyr" name="enrollyr" />
							</div>
						</div>
					</div>
					
					<div class="col-md-6 col-sm-12 col-xs-12">
						<div class="form-group">
						<label class="control-label col-md-4 col-sm-3 col-xs-12 lbl_reg" >City</label>
						<div class="col-md-8 col-sm-8 col-xs-12" >
							<input type="text" class="form-control"  id="city" name="city" />

						  </div>
						</div>
					</div>
				</div>
				<br>
					<div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12">
						<div class="form-group">
						 <label class="control-label col-md-2 col-sm-3 col-xs-12" >Country</label>
						  <div class="col-md-10 col-sm-9 col-xs-12">
							<input type="text" class="form-control"  id="country" name="country" />
							<input type="hidden" class="form-control"  placeholder="Enter Department Name" name="hide_field" id="hide_field"  maxlength="50">
					  </div>
					</div>
				</div>
				</div>
				<br>				
            </div>
      </div>
	        <div class="modal-footer">
          <button type="submit" class="btn btn-success">Submit</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </form>
      </div>
    </div>
  </div>
  </div>
<!--         update modal closeeeeeeeeeeeeeeeeee    -->

<!--      ---------------View modal Startttttttttttttttttttttt-->

 <div class="modal fade" style="width:100%;" id="view" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true">
    <div class="modal-dialog" style="width:80%; height:800px;">
      <div class="modal-content">
        <div class="modal-header">
          <button type="reset" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
          <h4 class="modal-title" id=""><strong>Update Student Record</strong></h4>
        </div>
       <div class="modal-body">
        <form class="form-horizontal" method="POST">
             <div class="modal-body">
				<div class="row">
				   <div class="col-md-6 col-sm-12 col-xs-12" id="">
						<div class="form-group">
						<label class="control-label col-md-4 col-sm-3 col-xs-12 lbl_reg">Student ID</label>						
						  <div class="col-md-8 col-sm-8 col-xs-12" >
							<input type="text" class="form-control"  id="studid" name="studid" readonly />
						  </div>
						</div>
					</div>
					<div class="col-md-6 col-sm-12 col-xs-12" id="">
						<div class="form-group">
						<label class="control-label col-md-4 col-sm-3 col-xs-12 lbl_reg">Student Name</label>						
						  <div class="col-md-8 col-sm-8 col-xs-12" >
							<input type="text" class="form-control"  id="studname" name="studname" readonly />
						  </div>
						</div>
					</div>
				</div>
				<br>
				<div class="row">
				<div class="col-md-6 col-sm-12 col-xs-12" id="">
				<div class="form-group">
						<label class="control-label col-md-4 col-sm-3 col-xs-12" >Class</label>
							<div class="col-md-8 col-sm-8 col-xs-12" id="">
							<input type="text" class="form-control"  id="class" name="class" readonly />
							</div>
							</div>
				</div>
					<div class="col-md-6 col-sm-12 col-xs-12">
						<div class="form-group">
						<label class="control-label col-md-4 col-sm-3 col-xs-12 lbl_reg">Email</label>						
						  <div class="col-md-8 col-sm-8 col-xs-12" >
						   <input type="text" class="form-control"  id="email" name="email" readonly />

						  </div>
						</div>
					
					</div>
			
				</div>
				<br>
				<div class="row">
				<div class="col-md-6 col-sm-12 col-xs-12">
						<div class="form-group">
						<label class="control-label col-md-4 col-sm-3 col-xs-12" >Enrollment Year</label>
							<div class="col-md-8 col-sm-8 col-xs-12">
									<input type="text" class="form-control" id="enrollyr" name="enrollyr" readonly />
							</div>
						</div>
					</div>
					
					<div class="col-md-6 col-sm-12 col-xs-12">
						<div class="form-group">
						<label class="control-label col-md-4 col-sm-3 col-xs-12 lbl_reg" >City</label>
						<div class="col-md-8 col-sm-8 col-xs-12" >
							<input type="text" class="form-control"  id="city" name="city" readonly />

						  </div>
						</div>
					</div>
				</div>
				<br>
					<div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12">
						<div class="form-group">
						 <label class="control-label col-md-2 col-sm-3 col-xs-12" >Country</label>
						  <div class="col-md-10 col-sm-9 col-xs-12">
							<input type="text" class="form-control"  id="country" name="country" readonly />
							<input type="hidden" class="form-control"  placeholder="Enter Department Name" name="hide_field" id="hide_field"  maxlength="50">
					  </div>
					</div>
				</div>
				</div>
				<br>				
            </div>
      </div>
	        <div class="modal-footer">
          <button type="submit" class="btn btn-success">Submit</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </form>
      </div>
    </div>
  </div>
  </div>
<!--         View modal closeeeeeeeeeeeeeeeeeeeeeeee    -->
			  
			    <div class="modal fade" id="delete" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
          <h4 class="modal-title" id=""><strong>Delete Student Record</strong></h4>
        </div>
        <div class="modal-body">
           <form class="form-horizontal" method="POST" action="process.php?action=delete_record">

            <div class="form-group">
              Do you really want to delete the specified record?
              <div class="col-sm-10">
                <input type="hidden" class="form-control" id="delete_id" name="delete_id">
              </div>
            </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-success">Submit</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </form>
      </div>
    </div>
  </div>


<script>
 $(document).on("click", ".deletebtn", function(){
            debugger;
              var id = $(this).val();
                $("#delete_id").val(id);
          });
		
$(document).on("click",".updatebtn",function(){
	 var values = $(this).val();
	//alert(values);
			$.ajax({
                url: 'process.php',
                type: 'POST',
                data: {action: 'student_update', id: values}
              })
              .done(function(html) {
			
                var data = JSON.parse(html);
			//alert(data);
               $("#stuid").val(data.Stud_id);
				$("#studname").val(data.stud_name);
				$("#class").val(data.email);
			    $("#email").val(data.class);
				$("#enrollyr").val(data.enroll_year);
			    $("#city").val(data.city);
				$("#country").val(data.country);
                $("#hide_field").val(values);
//alert(data);
              });
  });

 $(document).on("click",".viewbtn",function(){
	 var values = $(this).val();
	 //alert(values);
			$.ajax({
                url: 'process.php',
                type: 'POST',
                data: {action: 'viewstudent', id: values}
              })
              .done(function(html) {
                var data = JSON.parse(html);
			//alert(data);
               $("#stuid").val(data.Stud_id);
				$("#studname").val(data.stud_name);
				$("#class").val(data.email);
			    $("#email").val(data.class);
				$("#enrollyr").val(data.enroll_year);
			    $("#city").val(data.city);
				$("#country").val(data.country);
                $("#hide_field").val(values);
//alert(data);
              });
  });
		  
		  
</script>


</body>
</html>